#include<iostream>
class number{
    int num;
    public:
    number(int n){
        this.num=n;
    }
}
int main(){
    number n=new number(33);
    
}