<?php>
echo "Hello World";
$name= "Vansh Devgan";
echo "My name is ".$name;
$_GET= "Jatin Joshi";
// $_GET stores expected value from URL
$_GET['']
$_GET --> //Through URL
$_POST --> //Through Forms
$number=0;
if($number==0)
{
    echo "Number is 0";
}
else
{
    echo "Number is 1";
}
///////////////////////////////////////
$FullName=$_GET['name'];
$Password=$_GET['pass'];
echo $FullName;
echo $Password;
//////////////////////////////////////
echo $_GET['name'];
<?>