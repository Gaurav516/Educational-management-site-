/*
Type Conversion:
1. from primary type to class type
    a. using one argument constructor
    b. using operator=()
2. from class type to primary type
    a. using operator type(),here type can any primary type
*/
#include<iostream>
using namespace std;
class Number{
    int num;
    public:
        Number(int n):num{n}{
            cout<<"From Constructor...\n";
        }
        friend void operator<<(ostream &out, const Number &ref);
        void operator=(int num){
            this->num = num;
            cout<<"From Function Operator=()\n";
        }
        //it will typecast the data member to a primary type
        operator int(){
            return this->num;
        }
};
void operator<<(ostream &out,const Number &ref){
    out<<ref.num;
}
int main(){
    Number N1 =45; //using one argument constructor
    N1 = 56; //it will require an operator=() N1.operator=(56)
    cout<<N1;
    int k=N1; //N1.operator int ()
    cout<<endl<<k;
}